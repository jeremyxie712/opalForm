The language packs for dbv.php are stored in a [different repository](https://github.com/victorstanciu/dbv-language-packs), to keep the download size to a minimum.

If you want to contribute language packs, or help fix some of the existing translations, check out the public project page over at [POEditor.com](http://poeditor.com/join/project?hash=0e8914a77d653dc573b987cd1ace65d3)
