INSERT INTO `BuildType` (`Name`) VALUES
('Production');