INSERT INTO `SecurityQuestion` (`SecurityQuestionSerNum`, `QuestionText_EN`, `QuestionText_FR`, `CreationDate`, `LastUpdated`, `Active`) VALUES
(1, 'What was the name of your first pet?', 'Quel Ã©tait le nom de votre premier animal de compagnie?', '2016-10-18 15:03:56', '2018-03-23 14:39:13', 1),
(2, 'What is the first name of your childhood best friend?', 'Quel est le prÃ©nom de votre meilleur ami d''enfance?', '2016-10-18 15:03:56', '2018-03-23 14:39:14', 1),
(3, 'What is the name of your eldest niece?', 'Quel est le prÃ©nom de l''aÃ®nÃ©e de vos niÃ¨ces?', '2017-04-03 12:22:06', '2018-03-23 14:39:16', 1),
(4, 'What is the name of your eldest nephew?', 'Quel est le prÃ©nom de l''aÃ®nÃ© de vos neveux?', '2017-04-03 12:22:06', '2018-03-23 14:39:17', 1),
(5, 'What is the maiden name of your maternal grandmother?', 'Quel est le nom de jeune fille de votre grand-mÃ¨re maternelle?', '2017-04-03 12:22:32', '2018-03-23 14:39:18', 1),
(6, 'Where did you go to on your first vacation?', 'OÃ¹ Ãªtes-vous allÃ© lors de vos premiÃ¨res vacances?', '2017-04-03 12:22:32', '2018-03-23 14:39:19', 1);

