INSERT INTO `Cron` (`CronSerNum`, `NextCronDate`, `RepeatUnits`, `NextCronTime`, `RepeatInterval`, `LastCron`) VALUES
(1, '2018-05-03', 'Minutes', '13:05:00', 2, '2018-05-03 17:01:30');
