INSERT INTO `SourceDatabase` (`SourceDatabaseSerNum`, `SourceDatabaseName`, `Enabled`) VALUES
(1, 'Aria', 0),
(2, 'MediVisit', 0),
(3, 'Mosaiq', 0);
