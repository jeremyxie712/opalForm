INSERT INTO `AllowableExtension` (`Type`, `Name`) VALUES
('video', 'mov'),
('video', 'mp4'),
('website', 'be'),
('website', 'ca'),
('website', 'com'),
('website', 'html'),
('website', 'net'),
('website', 'org'),
('website', 'php'),
('website', 'uk'),
('pdf', 'pdf');
