INSERT INTO `PhaseInTreatment` (`PhaseInTreatmentSerNum`, `Name_EN`, `Name_FR`, `LastUpdated`) VALUES
(1, 'Prior To Treatment', 'Avant le traitement', '2016-04-01 00:28:25'),
(2, 'During Treatment', 'Au cours du traitement', '2016-04-01 00:28:57'),
(3, 'After Treatment', 'AprÃ¨s le traitement', '2016-04-01 00:29:18');
