INSERT INTO `OAUser` (`OAUserSerNum`, `Username`, `Password`, `Language`, `DateAdded`, `LastUpdated`) VALUES
(1, 'admin', '9575c78e5351af3746a845294532e436b3ccfc329ff09c21f2c89d2f6bdffd9f', 'EN', '2016-03-24 13:29:30', '2017-02-10 17:49:26');
