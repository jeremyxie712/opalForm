INSERT INTO `OAUserRole` (`OAUserSerNum`, `RoleSerNum`, `LastUpdated`) VALUES
(1, 1, '2017-02-10 17:49:26');
