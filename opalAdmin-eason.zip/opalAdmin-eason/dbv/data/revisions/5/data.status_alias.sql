INSERT INTO `StatusAlias` (`StatusAliasSerNum`, `SourceDatabaseSerNum`, `Name`, `Expression`, `DateAdded`, `LastUpdated`) VALUES
(1, 1, 'Open', 'Open', '2018-02-15 15:20:50', '2018-02-15 20:20:50'),
(2, 1, 'Completed', 'Completed', '2018-02-15 15:22:02', '2018-02-15 20:22:02'),
(3, 1, 'Completed', 'Manually Completed', '2018-02-15 15:22:02', '2018-02-15 20:22:02'),
(4, 1, 'Completed', 'Pt. CompltFinish', '2018-02-15 15:24:29', '2018-02-15 20:24:29'),
(5, 2, 'Open', 'Open', '2018-02-15 15:24:29', '2018-02-15 20:24:29'),
(6, 2, 'Completed', 'Completed', '2018-02-15 15:24:58', '2018-02-15 20:24:58'),
(7, 1, 'Cancelled', 'Cancelled - Patient No-Show', '2018-03-26 09:35:48', '2018-03-26 13:35:48'),
(8, 1, 'Cancelled', 'Cancelled', '2018-03-26 09:35:48', '2018-03-26 13:35:48');
